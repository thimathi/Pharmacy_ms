import LoginRegister from "./Components/LoginRegister/LoginRegister";


function App() {
  return (
    <div>
      <LoginRegister />
    </div>
  );
}

export default App;
