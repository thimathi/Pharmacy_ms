export const _id = (index: number) => `e99f09a7-dd88-49d5-b1c8-1daf80c2d7b${index}`;

export const _times = (index: number) =>
  // 'MM/DD/YYYY'
  [
    '11/08/2023',
    '04/09/2024',
    '09/12/2023',
    '01/01/2024',
    '04/23/2024',
    '02/29/2024',
    '05/14/2024',
    '01/13/2024',
    '06/22/2024',
    '10/05/2023',
    '07/11/2024',
    '05/22/2024',
    '03/29/2024',
    '08/29/2023',
    '11/19/2023',
    '10/24/2023',
    '12/02/2023',
    '02/13/2024',
    '09/19/2023',
    '04/17/2024',
    '12/18/2023',
    '06/27/2024',
    '10/19/2023',
    '08/09/2024',
  ][index];

export const _fullName = (index: number) =>
  [
    'Billy Stoltenberg',
    'Eloise Ebert',
    'Teresa Luettgen',
    'Salvador Mayert',
    'Dr. Guadalupe Rath',
    'Kelvin Pouros',
    'Thelma Langworth',
    'Kristen Wunsch',
    'Steve Welch',
    'Brian Jacobs',
    'Lillie Schultz',
    'Mr. Conrad Spinka',
    'Charlene Krajcik',
    'Kerry Kuhlman',
    'Betty Hammes',
    'Tony Paucek PhD',
    'Sherri Davis',
    'Angel Rolfson-Kulas',
    'Dr. Lee Doyle-Grant',
    'Cheryl Romaguera',
    'Billy Braun',
    'Adam Trantow',
    'Brandon Von',
    'Willis Ankunding',
  ][index];

export const _price = (index: number) =>
    [
        35.17,  // Tylenol Extra Strength
        57.22,  // Advil Pain Reliever
        64.78,  // Aleve Naproxen Sodium
        50.79,  // Amoxicillin 500 mg
        9.57,   // Ciprofloxacin 500 mg
        61.46,  // Doxycycline 100 mg
        96.73,  // Claritin Allergy Relief
        63.04,  // Zyrtec Antihistamine
        33.18,  // Benadryl Allergy Medicine
        36.3,   // Prozac Fluoxetine
        54.42,  // Zoloft Sertraline
        20.52,  // Cymbalta Duloxetine
        62.82,  // Lipitor Atorvastatin
        19.96,  // Norvasc Amlodipine
        25.93,  // Lisinopril 20 mg
        70.39,  // Metformin 500 mg
        23.11,  // Insulin Humulin R
        67.23,  // Glipizide Extended Release
        14.31,  // Crestor Rosuvastatin
        31.5,   // Zocor Simvastatin
        26.72,  // Pravachol Pravastatin
        44.8,   // Tamiflu Oseltamivir
        37.87,  // Valtrex Valacyclovir
        75.53,  // Acyclovir 400 mg
        28.99,  // Pepcid AC
        38.25,  // Prilosec OTC
        12.49,  // Tums Antacid
        22.67,  // Flonase Nasal Spray
        29.14,  // Allegra Fexofenadine
        31.77,  // Singulair Montelukast
    ][index];


export const _company = (index: number) =>
  [
      'PharmaTech Solutions',
      'MedPro Industries',
      'BioHealth Corp',
      'NeuroPharm LLC',
      'GenX Pharmaceuticals',
      'Vista Biotech',
      'TheraGen Inc.',
      'Advanced Medics',
      'Optima Health Solutions',
      'Prime Pharma Co.',
      'Innovative Care Ltd.',
      'Precision Pharma',
      'MedElite Pharmaceuticals',
      'Global Health Systems',
      'Vertex Biopharma',
      'CoreMed Technologies',
      'NexGen Therapeutics',
      'Eterna Health',
      'Zenith Biopharma',
      'Revita Health Solutions',
      'CureAll Pharmaceuticals',
      'Advanced BioTech',
      'Quantum Medics',
  ][index];

export const _boolean = (index: number) =>
  [
    true,
    false,
    true,
    false,
    true,
    true,
    true,
    false,
    false,
    true,
    false,
    true,
    true,
    false,
    true,
    false,
    false,
    true,
    false,
    false,
    false,
    true,
    true,
    false,
  ][index];

export const _postTitles = (index: number) =>
  [
      'Breakthrough in Cancer Immunotherapy',
      'Advances in Alzheimer’s Disease Treatment',
      'Top 10 Medications for Managing Diabetes',
      'New Guidelines for Hypertension Management',
      'The Role of Genetics in Personalized Medicine',
      'Understanding Modern Vaccination Strategies',
      'Innovations in Cardiac Care Technologies',
      'Emerging Trends in Pain Management',
      'The Future of Telemedicine in Patient Care',
      'Recent Developments in Antiviral Medications',
      'Evaluating the Effectiveness of New Antibiotics',
      'How Precision Medicine is Changing Cancer Treatment',
      'Understanding the Impact of Drug-Drug Interactions',
      'New Approaches to Managing Chronic Respiratory Diseases',
      'Advancements in Diabetes Monitoring Devices',
      'The Role of Artificial Intelligence in Drug Discovery',
      'New Insights into Autoimmune Disease Treatments',
      'How to Improve Patient Adherence to Medications',
      'Recent Breakthroughs in Gene Therapy',
      'The Benefits of Integrative Medicine Approaches',
      'Managing Side Effects of New Psychiatric Medications',
      'The Impact of Lifestyle Changes on Cardiovascular Health',
  ][index];

export const _description = (index: number) =>
  [
      'A comprehensive overview of the latest advancements in immunotherapy for cancer treatment, focusing on new drug developments and clinical trials.',
      'An in-depth analysis of recent progress in the treatment and management of Alzheimer’s disease, including novel therapeutic approaches and research findings.',
      'A guide to the most effective medications for controlling diabetes, including new and existing options for glycemic management and patient care.',
      'Updated recommendations and protocols for managing high blood pressure, including lifestyle modifications and pharmacological interventions.',
      'Exploration of how genetic information is being used to tailor medical treatments to individual patients, enhancing the efficacy and safety of therapies.',
      'An overview of the latest strategies and vaccines developed to combat infectious diseases, with a focus on recent innovations and public health impact.',
      'Discussion of cutting-edge technologies and methods in cardiac care, including new devices, procedures, and treatment modalities for heart disease.',
      'Examination of the latest developments in managing chronic pain, including new medication options, alternative therapies, and patient outcomes.',
      'Insights into how telemedicine is transforming patient care, with an emphasis on remote consultations, digital health tools, and patient engagement.',
      'Review of recent advancements in antiviral drugs, including new medications for treating viral infections and their effectiveness compared to existing treatments.',
      'Assessment of new antibiotics introduced to combat bacterial infections, including their efficacy, safety profile, and resistance patterns.',
      'Analysis of how precision medicine is revolutionizing cancer care, with a focus on targeted therapies, personalized treatment plans, and patient outcomes.',
      'Explanation of the significance of drug-drug interactions, including how they affect treatment efficacy and strategies to manage potential adverse effects.',
      'Overview of new methods and devices for monitoring chronic respiratory diseases, including advancements in technology and patient management strategies.',
      'Exploration of how artificial intelligence is being utilized in drug discovery, with a focus on improving drug development processes and accelerating research.',
      'Insights into new treatment approaches for autoimmune diseases, including emerging therapies and clinical trials aimed at improving patient outcomes.',
      'Strategies for enhancing patient adherence to prescribed medications, including interventions, support systems, and adherence monitoring techniques.',
      'Overview of recent breakthroughs in gene therapy, including new treatments for genetic disorders and the potential for future applications.',
      'Discussion of how integrative medicine approaches are being used to complement conventional treatments, with a focus on holistic patient care.',
      'Analysis of the side effects associated with new psychiatric medications, including management strategies and impact on patient quality of life.',
      'Examination of how lifestyle changes can positively influence cardiovascular health, including diet, exercise, and other preventive measures.',
  ][index];

export const _taskNames = (index: number) =>
  [
      `Review Latest Clinical Trial Results`,
      `Update Drug Interaction Database`,
      `Prepare Report on New Drug Approvals`,
      `Conduct Research on Emerging Therapies`,
      `Analyze Patient Outcomes for New Medications`,
      `Evaluate Efficacy of Recent Vaccines`,
      `Develop Protocol for Chronic Disease Management`,
      `Assess Safety of Newly Approved Medications`,
      `Monitor Trends in Telemedicine Utilization`,
      `Draft Guidelines for Personalized Medicine`,
      `Organize Seminar on Advances in Pain Management`,
      `Prepare Case Studies on Recent Treatment Innovations`,
      `Review Literature on Autoimmune Disease Treatments`,
      `Update Guidelines for Diabetes Care`,
      `Compile Data on New Cardiovascular Therapies`,
      `Develop Training Materials for Medication Adherence`,
      `Draft Press Release on Breakthrough Therapies`,
      `Conduct Webinar on Drug Safety Practices`,
      `Evaluate Impact of AI in Drug Discovery`,
      `Plan Research Symposium on Gene Therapy`,
      `Review Patient Feedback on New Psychiatric Drugs`,
      `Update Best Practices for Cardiovascular Health`,
  ][index];

export const _productNames = (index: number) =>
  [
      'Tylenol Extra Strength',
      'Advil Pain Reliever',
      'Aleve Naproxen Sodium',
      'Amoxicillin 500 mg',
      'Ciprofloxacin 500 mg',
      'Doxycycline 100 mg',
      'Claritin Allergy Relief',
      'Zyrtec Antihistamine',
      'Benadryl Allergy Medicine',
      'Prozac Fluoxetine',
      'Zoloft Sertraline',
      'Cymbalta Duloxetine',
      'Lipitor Atorvastatin',
      'Norvasc Amlodipine',
      'Lisinopril 20 mg',
      'Metformin 500 mg',
      'Insulin Humulin R',
      'Glipizide Extended Release',
      'Crestor Rosuvastatin',
      'Zocor Simvastatin',
      'Pravachol Pravastatin',
      'Tamiflu Oseltamivir',
      'Valtrex Valacyclovir',
      'Acyclovir 400 mg',
      'Pepcid AC',
      'Prilosec OTC',
      'Tums Antacid',
      'Flonase Nasal Spray',
      'Allegra Fexofenadine',
      'Singulair Montelukast',
  ][index];
