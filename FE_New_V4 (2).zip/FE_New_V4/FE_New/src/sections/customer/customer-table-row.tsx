import axios from 'axios';
import React, { useState, useCallback } from 'react';

import { Dialog, Button, Popover, TableRow, Checkbox, MenuItem, TableCell, TextField, IconButton, DialogTitle, DialogContent, DialogActions } from '@mui/material';

import { Iconify } from 'src/components/iconify';

interface CustomerTableRowProps {
    row: any;
    selected: boolean;
    onSelectRow: () => void;
    onSave: (updatedCustomer: any) => void;
}

export function CustomerTableRow({ row, selected, onSelectRow, onSave }: CustomerTableRowProps) {
    const [editMode, setEditMode] = useState(false);
    const [editableRow, setEditableRow] = useState({ ...row });
    const [openPopover, setOpenPopover] = useState<HTMLButtonElement | null>(null);
    const [openDialog, setOpenDialog] = useState(false);

    const handleOpenPopover = useCallback((event: React.MouseEvent<HTMLButtonElement>) => {
        setOpenPopover(event.currentTarget);
    }, []);

    const handleClosePopover = useCallback(() => {
        setOpenPopover(null);
    }, []);

    const handleToggleEdit = () => {
        setEditMode(!editMode);
        setEditableRow({ ...row });
    };

    const handleOpenDialog = () => {
        setOpenDialog(true);
        setEditableRow({ ...row });
    };

    const handleCloseDialog = () => {
        setOpenDialog(false);
    };

    const handleChange = (prop: string, value: any) => {
        setEditableRow((prev: any) => ({ ...prev, [prop]: value }));
    };

    const handleSave = async () => {
        try {
            const token = sessionStorage.getItem('token');
            const updateCustomer = {
                id:editableRow.id,
                address: editableRow.address,
                dateOfBirth: editableRow.dateOfBirth,
                email: editableRow.email,
                firstName: editableRow.firstName,
                lastName: editableRow.lastName,
                phoneNumber: editableRow.phoneNumber
            }
            const response = await axios.put(`${import.meta.env.VITE_BASE_URL}/customer/customers`, updateCustomer, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.status === 200) {
                onSave(editableRow); // Pass the updated data back up for re-render
                handleCloseDialog(); // Close dialog after successful update
                alert("Update successfully!");
                window.location.reload();
            }
        } catch (error) {
            console.error('Failed to update customer:', error);
        }
    };

    const handleDelete = async () => {
        try {
            const token = sessionStorage.getItem('token');
            const response = await axios.delete(`${import.meta.env.VITE_BASE_URL}/customer/customers/${row.id}`, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.status === 200) {
                alert("Customer deleted successfully!");
                window.location.reload(); // Reload to update the list of customers
            }
        } catch (error) {
            console.error('Failed to delete customer:', error);
            alert("Failed to delete customer.");
        }
    };

    return (
        <TableRow hover tabIndex={-1} role="checkbox" selected={selected}>
            <TableCell padding="checkbox">
                <Checkbox disableRipple checked={selected} onChange={onSelectRow} />
            </TableCell>
            <TableCell component="th" scope="row">{row.id}</TableCell>
            <TableCell>{row.firstName}</TableCell>
            <TableCell>{row.lastName}</TableCell>
            <TableCell>{row.dateOfBirth}</TableCell>
            <TableCell>{row.phoneNumber}</TableCell>
            <TableCell>{row.email}</TableCell>
            <TableCell>{row.address}</TableCell>
            <TableCell align="right">
                <IconButton onClick={handleOpenPopover}>
                    <Iconify icon="eva:more-vertical-fill" />
                </IconButton>
                <Popover
                    open={!!openPopover}
                    anchorEl={openPopover}
                    onClose={handleClosePopover}
                    anchorOrigin={{ vertical: 'top', horizontal: 'left' }}
                    transformOrigin={{ vertical: 'top', horizontal: 'right' }}
                >
                    <MenuItem onClick={handleOpenDialog}>
                        <Iconify icon="solar:pen-bold" />
                        Edit
                    </MenuItem>
                    <MenuItem onClick={handleDelete} sx={{ color: 'error.main' }}>
                        <Iconify icon="solar:trash-bin-trash-bold" />
                        Delete
                    </MenuItem>
                </Popover>
            </TableCell>

            <Dialog open={openDialog} onClose={handleCloseDialog} aria-labelledby="form-dialog-title">
                <DialogTitle id="form-dialog-title">Update Customer</DialogTitle>
                <DialogContent>
                    <TextField
                        autoFocus
                        margin="dense"
                        id="first_name"
                        label="First Name"
                        type="text"
                        fullWidth
                        value={editableRow.firstName}
                        onChange={(e) => handleChange('first_name', e.target.value)}
                        disabled
                    />
                    <TextField
                        margin="dense"
                        id="last_name"
                        label="Last Name"
                        type="text"
                        fullWidth
                        value={editableRow.lastName}
                        onChange={(e) => handleChange('last_name', e.target.value)}
                        disabled
                    />
                    <TextField
                        margin="dense"
                        id="date_of_birth"
                        label="Date of Birth"
                        type="date"
                        fullWidth
                        InputLabelProps={{ shrink: true }}
                        value={editableRow.dateOfBirth}
                        onChange={(e) => handleChange('date_of_birth', e.target.value)}
                        disabled
                    />
                    <TextField
                        margin="dense"
                        id="phone_number"
                        label="Phone Number"
                        type="text"
                        fullWidth
                        value={editableRow.phoneNumber}
                        onChange={(e) => handleChange('phone_number', e.target.value)}
                        disabled
                    />
                    <TextField
                        margin="dense"
                        id="email"
                        label="Email"
                        type="email"
                        fullWidth
                        value={editableRow.email}
                        onChange={(e) => handleChange('email', e.target.value)}
                    />
                    <TextField
                        margin="dense"
                        id="address"
                        label="Address"
                        type="text"
                        fullWidth
                        value={editableRow.address}
                        onChange={(e) => handleChange('address', e.target.value)}
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseDialog} color="primary">
                        Cancel
                    </Button>
                    <Button onClick={handleSave} color="primary">
                        Save
                    </Button>
                </DialogActions>
            </Dialog>
        </TableRow>
    );
}
