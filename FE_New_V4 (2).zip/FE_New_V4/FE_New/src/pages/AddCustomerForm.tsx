import axios from 'axios';
import React, { useState } from 'react';
import { Box, Button, TextField, Typography } from '@mui/material';

export default function AddCustomerForm() {
    const [customer, setCustomer] = useState({
        first_name: '',
        last_name: '',
        date_of_birth: '',
        phone_number: '',
        email: '',
        address: ''
    });

    // @ts-ignore
    const handleChange = (prop) => (event) => {
        setCustomer({ ...customer, [prop]: event.target.value });
    };

    // @ts-ignore
    const handleSubmit = async (event) => {
        event.preventDefault();

        try {
            const token = sessionStorage.getItem('token');
            const newCustomerObj = {
                first_name: customer.first_name,
                last_name: customer.last_name,
                date_of_birth: customer.date_of_birth,
                phone_number: customer.phone_number,
                email: customer.email,
                address: customer.address
            };
            console.log("======", newCustomerObj);
            const response = await axios.post(`${import.meta.env.VITE_BASE_URL}/customer/customers`, newCustomerObj, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                }
            });

            alert("Customer added successfully");
            console.log('Customer added successfully:', response.data);
            // Add logic here for success handling, e.g., displaying a success message

            // Clear form fields after successful submission
            setCustomer({
                first_name: '',
                last_name: '',
                date_of_birth: '',
                phone_number: '',
                email: '',
                address: ''
            });

        } catch (error) {
            console.error('Failed to add customer:', error);
            alert('Failed to add customer.');
        }
    };

    return (
        <Box
            component="form"
            sx={{
                display: 'flex',
                flexDirection: 'column',
                m: 2,
                '& .MuiTextField-root': { m: 1, width: '100%' }
            }}
            noValidate
            autoComplete="off"
            onSubmit={handleSubmit}
        >
            <Typography variant="h6" sx={{ mb: 2 }}>
                Add New Customer
            </Typography>
            <TextField
                required
                label="First Name"
                value={customer.first_name}
                onChange={handleChange('first_name')}
            />
            <TextField
                required
                label="Last Name"
                value={customer.last_name}
                onChange={handleChange('last_name')}
            />
            <TextField
                required
                label="Date of Birth"
                type="date"
                value={customer.date_of_birth}
                onChange={handleChange('date_of_birth')}
                InputLabelProps={{ shrink: true }}
            />
            <TextField
                required
                label="Phone Number"
                value={customer.phone_number}
                onChange={handleChange('phone_number')}
                inputProps={{ maxLength: 20 }}
            />
            <TextField
                required
                label="Email"
                value={customer.email}
                onChange={handleChange('email')}
            />
            <TextField
                required
                label="Address"
                value={customer.address}
                onChange={handleChange('address')}
                multiline
                rows={4}
            />
            <Button type="submit" variant="contained" color="primary" sx={{ mt: 3, alignSelf: 'flex-start' }}>
                Add Customer
            </Button>
        </Box>
    );
}
