import React from 'react';
import { Box, Typography } from '@mui/material';
import AddCustomerForm from "./AddCustomerForm"; // Adjust the path as necessary

export default function AddCustomerPage() {
    return (
        <Box sx={{ p: 3 }}>
            <Typography variant="h4" sx={{ mb: 3 }}>
                Add New Customer
            </Typography>
            <AddCustomerForm />
        </Box>
    );
}
