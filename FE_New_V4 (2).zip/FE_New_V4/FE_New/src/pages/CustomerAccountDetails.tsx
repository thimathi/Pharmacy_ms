import axios from 'axios';
import React, { useState } from 'react';

import { Box, Button, TextField, Typography } from '@mui/material';


export default function CustomerAccountDetails() {
    const [customer, setCustomer] = useState({
        first_name: '',
        last_name: '',
        address: '',
        mobile: '',
        email: '',
        date_of_birth: '', // Adding date_of_birth field
        phone_number: '', // Adding phone_number field
    });
    const [showPassword, setShowPassword] = useState(false);
    const [loading, setLoading] = useState(true); // Loading state
    const [error, setError] = useState(''); // Error handling state

    const handleChange = (prop: string) => (event: { target: { value: any; }; }) => {
        setCustomer(prev => ({ ...prev, [prop]: event.target.value }));
    };

    const handleUpdate = async () => {
        const token = sessionStorage.getItem('token');
        const customerId = sessionStorage.getItem('customerId');

        console.log("----------",customer);

        try {
            const response = await axios.post(`${import.meta.env.VITE_BASE_URL}/customer/customers`, {
                firstName: customer.first_name,
                lastName: customer.last_name,
                dateOfBirth: customer.date_of_birth,
                phoneNumber: customer.phone_number,
                email:customer.email,
                address: customer.address,
            }, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                }
            });

            if (response.status === 200) {
                alert("Create successfully!");
                window.location.reload();
                // Optionally, you can redirect or update UI here
            }
            // eslint-disable-next-line @typescript-eslint/no-shadow
        } catch (error) {
            console.error('Failed to update customer:', error);
            setError('Failed to update customer data.');
        }
    };

    return (
        <Box
            component="form"
            sx={{
                display: 'flex',
                flexDirection: 'column',
                m: 2,
                '& .MuiTextField-root': { m: 1, width: '100%' }
            }}
            noValidate
            autoComplete="off"
            onSubmit={(event) => {
                event.preventDefault();
                handleUpdate();
            }}
        >
            <Typography variant="h6" sx={{ mb: 2 }}>
                My Account
            </Typography>
            {error && <Typography color="error">{error}</Typography>}
            <TextField
                label="First Name"
                value={customer.first_name}
                onChange={handleChange('first_name')}
                required
            />
            <TextField
                label="Last Name"
                value={customer.last_name}
                onChange={handleChange('last_name')}
                required
            />
            <TextField
                label="Email"
                value={customer.email}
                onChange={handleChange('email')}
                type="email"
                required
            />
            <TextField
                label="Address"
                value={customer.address}
                onChange={handleChange('address')}
                required
            />
            <TextField
                label="Mobile"
                value={customer.mobile}
                onChange={handleChange('mobile')}
                inputProps={{ maxLength: 20 }} // Adjust maxLength as needed
                required
            />
            <TextField
                label="Phone Number"
                value={customer.phone_number}
                onChange={handleChange('phone_number')}
                inputProps={{ maxLength: 20 }} // Adjust maxLength as needed
            />
            <TextField
                label="Date of Birth"
                value={customer.date_of_birth}
                onChange={handleChange('date_of_birth')}
                type="date"
                InputLabelProps={{ shrink: true }}
                sx={{ mb: 3 }}
            />
            <Button type="submit" variant="contained" color="primary" sx={{ mt: 3, alignSelf: 'center' }}>
                Update
            </Button>
        </Box>
    );
}
