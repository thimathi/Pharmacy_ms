package the.boys.pharmacy_management_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PharmacyManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
