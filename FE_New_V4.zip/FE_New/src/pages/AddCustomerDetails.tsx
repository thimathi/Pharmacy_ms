import React from 'react';
import { Box, Typography } from '@mui/material';
import CustomerAccountDetails from './CustomerAccountDetails'; // Adjust the path as necessary

export default function AddCustomerDetails() {
    return (
        <Box sx={{ p: 3 }}>
            <Typography variant="h4" sx={{ mb: 3 }}>
                Add New Customer
            </Typography>
            <CustomerAccountDetails />
        </Box>
    );
}
